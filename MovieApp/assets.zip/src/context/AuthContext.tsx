import React, { createContext, useContext, useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export type User = {
  username: string;
  password: string;
  email: string;
};

interface AuthContextType {
  isLoggedIn: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  register: (
    username: string,
    password: string,
    email: string
  ) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: any) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const checkLoginStatus = async () => {
      const loggedIn = await AsyncStorage.getItem("isLoggedIn");
      if (loggedIn === "true") {
        setIsLoggedIn(true);
      }
    };
    checkLoginStatus();
  }, []);

  const login = async (username: string, password: string) => {
    const usersData = await AsyncStorage.getItem("users");
    if (usersData) {
      const users: User[] = JSON.parse(usersData);
      const user = users.find(
        (u) => u.username === username && u.password === password
      );
      if (user) {
        setIsLoggedIn(true);
        await AsyncStorage.setItem("isLoggedIn", "true");
        await AsyncStorage.setItem("currentUser", JSON.stringify(user));
      } else {
        throw new Error("Invalid username or password");
      }
    } else {
      throw new Error("User not registered");
    }
  };

  const logout = () => {
    setIsLoggedIn(false);
    AsyncStorage.removeItem("isLoggedIn");
    AsyncStorage.removeItem("currentUser");
  };

  const register = async (
    username: string,
    password: string,
    email: string
  ) => {
    const usersData = await AsyncStorage.getItem("users");
    const users: User[] = usersData ? JSON.parse(usersData) : [];

    const userExists = users.some((u) => u.username === username);
    if (userExists) {
      throw new Error("User already registered");
    } else {
      if (!password) {
        throw new Error("Password is required");
      }

      const newUser: User = { username, password, email };
      users.push(newUser);
      await AsyncStorage.setItem("users", JSON.stringify(users));
    }
  };

  return (
    <AuthContext.Provider value={{ isLoggedIn, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
