import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Image,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { StatusBar } from "expo-status-bar";
import { useAuth, User } from "../context/AuthContext";
import AsyncStorage from "@react-native-async-storage/async-storage";

const ProfileScreen = ({ navigation }: any) => {
  const { logout } = useAuth();
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const storedCurrentUser = await AsyncStorage.getItem("currentUser");
        if (storedCurrentUser) setCurrentUser(JSON.parse(storedCurrentUser));
      } catch (error) {
        console.error("Error loading user data:", error);
      }
    };
    loadUserData();
  }, []);

  const handleLogout = async () => {
    await logout();
    navigation.navigate("Home");
  };

  return (
    <ScrollView style={styles.container}>
      <StatusBar style="light" />
      <LinearGradient
        colors={["rgba(252, 9, 76, 0.8)", "transparent"]}
        style={styles.gradient}
      />
      <View style={styles.header}>
        <Text style={styles.title}>Профиль</Text>
        <Pressable style={styles.button} onPress={() => navigation.goBack()}>
          <Text style={styles.buttonText}>Назад</Text>
        </Pressable>
      </View>

      <View style={styles.profileInfo}>
        <Image
          style={styles.avatar}
          source={{ uri: "https://via.placeholder.com/150" }}
        />
        <Text style={styles.name}>
          {currentUser?.username || "Пользователь"}
        </Text>
        <Text style={styles.email}>
          {currentUser?.email || "email@example.com"}
        </Text>
      </View>

      {/* <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>42</Text>
          <Text style={styles.statLabel}>Просмотрено фильмов</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>15</Text>
          <Text style={styles.statLabel}>Рецензий</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>8</Text>
          <Text style={styles.statLabel}>Списков</Text>
        </View>
      </View> */}

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Любимые жанры</Text>
        <View style={styles.genreContainer}>
          {["Драма", "Комедия", "Фантастика", "Триллер"].map((genre) => (
            <View key={genre} style={styles.genreItem}>
              <Text style={styles.genreText}>{genre}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Настройки</Text>
        <Pressable style={styles.settingItem}>
          <Text style={styles.settingText}>Изменить пароль</Text>
        </Pressable>
      </View>

      <Pressable style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutButtonText}>Выйти</Text>
      </Pressable>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1B1819",
  },
  gradient: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    height: 200,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingTop: 60,
    paddingHorizontal: 24,
    marginBottom: 20,
  },
  title: {
    color: "#FFFFFF",
    fontSize: 24,
    fontFamily: "Poppins",
    fontWeight: "bold",
  },
  button: {
    backgroundColor: "#FC094C",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "bold",
  },
  profileInfo: {
    alignItems: "center",
    marginBottom: 24,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  name: {
    color: "#FFFFFF",
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 8,
  },
  email: {
    color: "#CCCCCC",
    fontSize: 16,
  },
  statsContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 24,
  },
  statItem: {
    alignItems: "center",
  },
  statValue: {
    color: "#FC094C",
    fontSize: 24,
    fontWeight: "bold",
  },
  statLabel: {
    color: "#CCCCCC",
    fontSize: 14,
  },
  section: {
    marginBottom: 24,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 16,
  },
  genreContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  genreItem: {
    backgroundColor: "#FC094C",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
  },
  genreText: {
    color: "#FFFFFF",
    fontSize: 14,
  },
  settingItem: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#333",
  },
  settingText: {
    color: "#FFFFFF",
    fontSize: 16,
  },
  logoutButton: {
    backgroundColor: "#FC094C",
    paddingVertical: 16,
    marginHorizontal: 24,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 24,
  },
  logoutButtonText: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "bold",
  },
});

export default ProfileScreen;
